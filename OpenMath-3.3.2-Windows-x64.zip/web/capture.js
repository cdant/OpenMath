'use strict';
// Capture the actual editable mathfield, including its role fonts and stretchy glyphs.
// A fixed 4x render scale is independent of the editor's display zoom and Word fonts.
window.FormulaCapture = (() => {
 let saved;
 const frame=()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
 async function begin() {
  if(saved)throw Error('公式图像正在生成。');
  const value=payload(),field=document.getElementById('formula');
  const size=Number(new DOMParser().parseFromString(value.mathml,'application/xml').documentElement.getAttribute('data-fs-size'))||12;
  saved={parent:field.parentNode,next:field.nextSibling,style:field.getAttribute('style'),selection:field.selection,readonly:field.readOnly,htmlOverflow:document.documentElement.style.overflow,bodyOverflow:document.body.style.overflow};
  document.documentElement.style.overflow='hidden';document.body.style.overflow='hidden';
  field.blur();field.selection={ranges:[[field.lastOffset,field.lastOffset]],direction:'forward'};field.readOnly=true;
  const layer=document.createElement('div');layer.id='fs-capture-layer';layer.style.cssText='position:fixed;inset:0;background:white;z-index:2147483647;overflow:hidden;';
  document.body.append(layer);layer.append(field);
  saved.bleed=Math.ceil(size*96/72*4);
  field.style.cssText=`position:absolute;left:${saved.bleed}px;top:${saved.bleed}px;display:inline-block;width:max-content;max-width:none;min-width:0;min-height:0;overflow:visible;margin:0;padding:0;border:0;border-radius:0;box-shadow:none;background:white;color:black;font-size:${size*96/72*4}px;`;
  const css=document.createElement('style');css.id='fs-capture-rules';css.textContent='.ML__caret,.ML__selection,.ML__contains-caret:after,.ML__focused .ML__caret{display:none!important}.ML__container,.ML__content,.ML__latex{overflow:visible!important}.ML__content{padding:0!important;min-width:0!important}.ML__placeholder{background:transparent!important;border-color:transparent!important}';field.shadowRoot.append(css);
  await document.fonts.ready;await frame();
  const marker=document.createElement('span');marker.id='fs-baseline-marker';marker.style.cssText='display:inline-block;width:0;height:0;padding:0;margin:0;vertical-align:baseline';field.shadowRoot.querySelector('.ML__latex').append(marker);await frame();
  const rect=field.getBoundingClientRect();const width=Math.ceil(rect.width)+2*saved.bleed,height=Math.ceil(rect.height)+2*saved.bleed,depth=Math.max(0,height-marker.getBoundingClientRect().top);
  if(width<1||height<1||width*height>32000000||width>24000||height>24000){end();throw Error('公式图像过大，请拆分后插入。');}
  marker.remove();return {width,height,widthPt:width*72/(96*4),heightPt:height*72/(96*4),depthPt:depth*72/(96*4),viewportWidth:innerWidth,viewportHeight:innerHeight,scale:4};
 }
 async function tile(x,y){const field=document.getElementById('formula');field.style.left=(saved.bleed-x)+'px';field.style.top=(saved.bleed-y)+'px';await frame();return true;}
 function end(){if(!saved)return;const field=document.getElementById('formula');field.shadowRoot.getElementById('fs-capture-rules')?.remove();saved.parent.insertBefore(field,saved.next);if(saved.style===null)field.removeAttribute('style');else field.setAttribute('style',saved.style);field.readOnly=saved.readonly;field.selection=saved.selection;document.getElementById('fs-capture-layer')?.remove();document.documentElement.style.overflow=saved.htmlOverflow;document.body.style.overflow=saved.bodyOverflow;saved=null;}
 return {begin,tile,end};
})();
