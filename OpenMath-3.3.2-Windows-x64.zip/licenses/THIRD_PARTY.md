Formula Studio uses MathLive 0.111.4 and bundled mathematical fonts, Microsoft WebView2 SDK 1.0.4314.35, and the separately installed WebView2 Runtime. License and notice texts for the redistributed components are in `licenses/`.

Version 2.0 includes a local modification to MathLive's MathML serializer for overline/underline atoms, so the body and bar decoration are preserved during export. The upstream source remains unchanged in vendor/. build.ps1 applies the documented, bounded patch when generating web/lib/mathlive.js. The MathLive MIT license remains included.

REA 6.8.0 was used as a development analysis tool and is installed separately under the workspace `.rea-tools` directory. Its license is included for reference; REA is not required to run the editor.

Microsoft Word and WPS are separate applications and are not included. The Office MML2OMML.XSL stylesheet is read from an existing local Office installation when present. It is not redistributed.

MathType is the reference application. Its application files, proprietary fonts, icons and private formats are not part of this package. Formula Studio is an independent implementation and is not affiliated with or endorsed by the MathType vendor.
