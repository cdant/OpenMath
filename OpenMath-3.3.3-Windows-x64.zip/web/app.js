'use strict';
MathfieldElement.fontsDirectory='/lib/fonts';MathfieldElement.soundsDirectory=null;
const $=id=>document.getElementById(id),mf=$('formula'),latex=$('latex');
let sourceDirty=false,history=[],activePalette=null,activeSubject='algebra',inWordSession=false;
try{history=JSON.parse(localStorage.getItem('formula-history')||'[]').filter(x=>typeof x==='string').slice(0,20);}catch{}
function status(text,type=''){$('status').textContent=text;$('status').className=type;}
function sourceState(){$('source-state').textContent=sourceDirty?'已修改 · 尚未应用':'与编辑区同步';$('source-state').className=sourceDirty?'dirty':'';}
function persistDraft(){if(!inWordSession)try{localStorage.setItem('formula-draft',mf.value);localStorage.setItem('formula-draft-size',FormulaStyles.profile().size);localStorage.setItem('formula-draft-styles',JSON.stringify(FormulaStyles.get()));}catch{}$('formula-count').textContent=`源码 ${mf.value.length} 个字符`;}
function syncSource(){sourceDirty=false;latex.value=mf.value;sourceState();persistDraft();}
function setFormula(value){mf.value=value;syncSource();mf.focus();}
function payload(){if(sourceDirty)throw new Error('源码尚未应用，请先点击“应用源码”。');if(mf.value.includes('\\placeholder'))throw new Error('请先填写模板中的空槽。');const value=mf.getValue('latex-without-placeholders');if(!value.trim())throw new Error('请先输入公式。');if(mf.errors.length)throw new Error('公式含有无效命令，请检查 LaTeX 源码。');const markup=mf.getValue('math-ml');return{version:1,appVersion:'3.3.3',latex:value,mathml:FormulaStyles.decorate(markup)};}
function preview(value){const span=document.createElement('span');span.className='math-preview';span.setAttribute('aria-hidden','true');span.innerHTML=MathLive.convertLatexToMarkup(value.replaceAll('\\placeholder{}','\\square'),{defaultMode:'math',displayMode:true});return span;}
function closePopups(focusEditor=false){$('palette-popup').hidden=true;$('menu-popup').hidden=true;document.querySelectorAll('[aria-expanded="true"]').forEach(b=>b.setAttribute('aria-expanded','false'));activePalette=null;if(focusEditor)mf.focus();}
function placePopup(popup,anchor){const r=anchor.getBoundingClientRect();popup.style.left=Math.max(6,Math.min(r.left,window.innerWidth-popup.offsetWidth-8))+window.scrollX+'px';let top=r.bottom+2+window.scrollY;if(top+popup.offsetHeight>window.innerHeight+window.scrollY-30&&r.top>popup.offsetHeight)top=r.top-popup.offsetHeight-2+window.scrollY;popup.style.top=top+'px';}
function insertTemplate(entry){
 if(sourceDirty){status('请先应用修改后的源码，再插入模板。','error');return;}
 let value=entry.latex;const selected=mf.getValue(mf.selection,'latex');
 if(selected&&!selected.includes('\\placeholder')&&value.includes('#0'))value=value.replace('#0',()=>'{'+selected+'}');
 value=value.replaceAll('#0','\\placeholder{}');
 closePopups();mf.focus();mf.insert(value,{selectionMode:'placeholder',format:'latex'});syncSource();status('已插入：'+entry.name+(entry.latex.includes('#0')?'。使用 Tab 切换空槽。':''),'success');
}
function itemButton(entry,showName=false){const b=document.createElement('button');b.type='button';b.title=entry.name;b.setAttribute('aria-label',entry.name);b.append(preview(entry.preview));if(showName){b.className='search-result';const s=document.createElement('small');s.textContent=entry.name;b.append(s);}b.addEventListener('pointerdown',e=>e.preventDefault());b.onclick=()=>insertTemplate(entry);b.onmouseenter=b.onfocus=()=>{$('popup-description').textContent=entry.name+(entry.category?' · '+entry.category:'')+'　'+entry.latex.replaceAll('#0','□');};return b;}
function showPalette(group,anchor,search=false){
 const wasOpen=activePalette===group.id&&!$('palette-popup').hidden;closePopups();if(wasOpen&&!search)return;
 activePalette=group.id;anchor.setAttribute('aria-expanded','true');$('popup-title').textContent=group.name+'　'+group.items.length+' 项';$('palette-popup').setAttribute('aria-label',group.name);
 $('popup-grid').replaceChildren();$('popup-grid').className='popup-grid'+(group.symbol?' symbol-grid':'')+(group.id==='matrices'?' matrix-grid':'');
 for(const entry of group.items)$('popup-grid').append(itemButton(entry,search));
 if(!group.items.length){const empty=document.createElement('p');empty.textContent='没有匹配的模板或符号。';empty.className='empty';$('popup-grid').append(empty);}
 $('popup-description').textContent='方向键选择 · Enter 插入 · Esc 关闭';$('palette-popup').hidden=false;placePopup($('palette-popup'),anchor);
}
for(const [target,groups,symbol] of [['symbol-palettes',SYMBOL_PALETTES,true],['template-palettes',TEMPLATE_PALETTES,false]])for(const group of groups){
 const b=document.createElement('button');b.type='button';b.className='palette-button';b.dataset.palette=group.id;b.title=group.name;b.setAttribute('aria-label',group.name);b.setAttribute('aria-haspopup','dialog');b.setAttribute('aria-expanded','false');b.append(preview('\\textstyle '+group.icon));b.addEventListener('pointerdown',e=>e.preventDefault());b.onclick=()=>showPalette({...group,symbol},b);b.onkeydown=e=>{if(e.key==='ArrowDown'){e.preventDefault();showPalette({...group,symbol},b);$('popup-grid').querySelector('button')?.focus();}};$(target).append(b);
}
const QUICK=[...['\\alpha','\\beta','\\theta','\\pi','\\infty','\\le','\\ge','\\ne','\\times','\\pm','\\to'].map(v=>ALL_ITEMS.find(i=>i.latex===v)).filter(Boolean),TEMPLATE_PALETTES[1].items[0],TEMPLATE_PALETTES[1].items[6],TEMPLATE_PALETTES[2].items[0]];
for(const entry of QUICK)$('quick-bar').append(itemButton({...entry,preview:'\\textstyle '+entry.preview}));
function renderSubject(id){activeSubject=id;const group=SUBJECTS.find(g=>g.id===id);document.querySelectorAll('[data-subject]').forEach(b=>{b.classList.toggle('active',b.dataset.subject===id);b.setAttribute('aria-selected',String(b.dataset.subject===id));});$('subject-bar').replaceChildren();const entries=id==='custom'?history.map((value,i)=>item('收藏 '+(i+1),value)):group.items;for(const entry of entries)$('subject-bar').append(itemButton(entry));if(!entries.length){const b=document.createElement('button');b.textContent='＋ 收藏当前公式';b.onclick=()=>{addHistory();status('已收藏当前公式。','success');};$('subject-bar').append(b);}}
for(const group of SUBJECTS){const b=document.createElement('button');b.type='button';b.textContent=group.name;b.dataset.subject=group.id;b.setAttribute('role','tab');b.setAttribute('aria-controls','subject-bar');b.onclick=()=>{closePopups();renderSubject(group.id);};$('subject-tabs').append(b);}renderSubject('algebra');
function renderHistory(){$('history').replaceChildren();if(!history.length){const p=document.createElement('span');p.className='empty';p.textContent='还没有收藏。保存、导出、插入时也会自动记录公式。';$('history').append(p);}for(const value of history){const b=document.createElement('button');b.textContent=value;b.title=value;b.onclick=()=>setFormula(value);$('history').append(b);}if(activeSubject==='custom')renderSubject('custom');}
function addHistory(){if(!mf.value.trim())return;history=[mf.value,...history.filter(v=>v!==mf.value)].slice(0,20);try{localStorage.setItem('formula-history',JSON.stringify(history));}catch{}renderHistory();}renderHistory();
const pending=new Map();let counter=0;const native=Boolean(window.chrome?.webview);
function request(action,data={}){if(!native)return Promise.reject(new Error('此功能需要桌面版。请运行 OpenMath.exe。'));return new Promise((resolve,reject)=>{const id=String(++counter);const timer=setTimeout(()=>{pending.delete(id);reject(new Error('操作超时，请检查目标文档是否有未关闭的对话框。'));},120000);pending.set(id,{resolve,reject,timer});window.chrome.webview.postMessage({id,action,data});});}
if(native)window.chrome.webview.addEventListener('message',event=>{const msg=event.data;if(msg.event==='word-complete'){status(msg.message,'success');return;}if(msg.event==='word-error'){$('word').disabled=false;status(msg.message,'error');return;}if(msg.event==='load'){FormulaStyles.restore(msg.mathml);setFormula(msg.latex);status('已打开公式。','success');return;}const task=pending.get(msg.id);if(!task)return;pending.delete(msg.id);clearTimeout(task.timer);msg.ok?task.resolve(msg.result):task.reject(new Error(msg.error||'操作失败'));});
async function run(button,action,data,success){button.disabled=true;let waiting=false;status('正在处理…');try{const result=await request(action,data);if(result?.cancelled){status('已取消。');return;}addHistory();if(result?.pending){waiting=true;status('正在返回 Word，等待文档确认…');return;}status(success+(result?.path?' '+result.path:''),'success');}catch(e){status(e.message,'error');}finally{if(!waiting)button.disabled=false;}}
for(const action of ['word','wps','export','save'])$(action).onclick=()=>{closePopups();try{run($(action),action,payload(),{word:'已插入 Word，可继续编辑。',wps:'已插入 WPS，可继续编辑。',export:'已导出可编辑公式文档。',save:'已保存公式。'}[action]);}catch(e){status(e.message,'error');}};
$('open').onclick=()=>{closePopups();run($('open'),'open',{},'已打开公式。');};
for(const [id,format] of [['copy-latex','latex'],['copy-mathml','mathml']])$(id).onclick=async()=>{try{const data=payload();if(native)await request('copy',{text:data[format]});else await navigator.clipboard.writeText(data[format]);status('已复制 '+format.toUpperCase()+'。','success');}catch(e){status(e.message,'error');}};
latex.oninput=()=>{sourceDirty=true;sourceState();};
mf.addEventListener('input',()=>{if(!sourceDirty)latex.value=mf.value;persistDraft();});
$('apply').onclick=()=>{setFormula(latex.value);status(mf.errors.length?'源码含有无效命令，请检查。':'已应用源码。',mf.errors.length?'error':'success');};
latex.addEventListener('keydown',e=>{if(e.ctrlKey&&e.key==='Enter'){e.preventDefault();$('apply').click();}});
for(const command of ['undo','redo'])$(command).onclick=()=>{mf.executeCommand(command);syncSource();mf.focus();};
$('clear').onclick=()=>{closePopups();if(!mf.value&&!sourceDirty){FormulaStyles.reset();setFormula('');return;}$('confirm-clear').showModal();};
$('confirm-clear').addEventListener('close',()=>{if($('confirm-clear').returnValue==='clear'){mf.executeCommand('selectAll');mf.executeCommand('deleteBackward');syncSource();FormulaStyles.reset();mf.focus();status('已新建空白公式。');}});
$('history-add').onclick=()=>{try{payload();addHistory();status('已收藏当前公式。','success');}catch(e){status(e.message,'error');}};
$('close-popup').onclick=()=>closePopups(true);
$('template-search').addEventListener('input',()=>{const query=$('template-search').value.trim().toLowerCase();if(!query){closePopups();return;}const entries=ALL_ITEMS.filter(x=>(x.name+' '+x.category+' '+x.latex).toLowerCase().includes(query)).slice(0,90);showPalette({id:'search',name:'搜索结果',items:entries},$('template-search'),true);});
function matrixValue(value='#0'){return matrixLatex(Number($('matrix-rows').value),Number($('matrix-cols').value),$('matrix-style').value,value);}
function updateMatrix(){if(!$('matrix-form').checkValidity())return;$('matrix-preview').replaceChildren(preview(matrixValue().replaceAll('#0','\\placeholder{}')));}
$('matrix-custom').onclick=()=>{closePopups();updateMatrix();$('matrix-dialog').showModal();};
for(const id of ['matrix-rows','matrix-cols','matrix-style'])$(id).addEventListener('input',updateMatrix);
$('matrix-cancel').onclick=()=>$('matrix-dialog').close();
$('matrix-form').onsubmit=e=>{e.preventDefault();if(!$('matrix-form').reportValidity())return;const value=matrixValue();$('matrix-dialog').close();insertTemplate(item(`${$('matrix-rows').value}×${$('matrix-cols').value} 自定义矩阵`,value));};
$('zoom').onchange=()=>{FormulaStyles.updateEditor();try{localStorage.setItem('formula-zoom',$('zoom').value);}catch{}status('显示比例 '+$('zoom').value+'%（不改变导出字号）。');};
const wrap=command=>()=>insertTemplate(item(command==='mathrm'?'正体':command==='mathbf'?'粗体':'数学斜体','\\'+command+'{#0}'));
const toggle=name=>()=>{document.body.classList.toggle(name);closePopups();};
const click=id=>()=>$(id).click();
const MENUS=[
 ['文件(F)',[['新建','Ctrl+N',click('clear')],['打开公式…','Ctrl+O',click('open')],['保存公式…','Ctrl+S',click('save')],null,['保存格式文件…','',()=>formatFile('format-save')],['读取格式文件…','',()=>formatFile('format-load')],['复制格式','',()=>request('copy',{text:JSON.stringify(FormulaStyles.profile())}).then(()=>status('公式格式已复制。'))],null,['导出 DOCX…','',click('export')],['插入 Word','',click('word')],['插入 WPS','',click('wps')]]],
 ['编辑(E)',[['撤销','Ctrl+Z',click('undo')],['重做','Ctrl+Y',click('redo')],null,['全选','Ctrl+A',()=>{mf.focus();mf.executeCommand('selectAll');}],['复制 LaTeX','',click('copy-latex')],['复制 MathML','',click('copy-mathml')]]],
 ['视图(V)',[['符号面板','F5',toggle('hide-symbols')],['模板面板','F6',toggle('hide-templates')],['标尺','',toggle('hide-ruler')],['工具栏','',toggle('hide-toolbar')],null,['LaTeX 源码','',()=>{$('source-panel').open=!$('source-panel').open;}],['最近公式与收藏','',()=>{$('recent-panel').open=!$('recent-panel').open;}]]],
 ['格式(O)',[['自定义矩阵…','',click('matrix-custom')],['上标','',()=>insertTemplate(TEMPLATE_PALETTES[2].items[0])],['下标','',()=>insertTemplate(TEMPLATE_PALETTES[2].items[1])],['分式','Ctrl+F',()=>insertTemplate(TEMPLATE_PALETTES[1].items[0])],['平方根','Ctrl+R',()=>insertTemplate(TEMPLATE_PALETTES[1].items[6])]]],
 ['样式(S)',FormulaStyles.menus()],
 ['大小(Z)',[100,150,200,250].map(n=>[n+'% 显示比例','',()=>{$('zoom').value=String(n);$('zoom').onchange();}])],
 ['帮助(H)',[['使用方法与版本','F1',()=>{$('help-dialog').showModal();}]]]
];
for(const [name,entries] of MENUS){const b=document.createElement('button');b.textContent=name;b.setAttribute('role','menuitem');b.setAttribute('aria-haspopup','menu');b.setAttribute('aria-expanded','false');b.onclick=()=>{const open=b.getAttribute('aria-expanded')==='true';closePopups();if(open)return;b.setAttribute('aria-expanded','true');$('menu-popup').replaceChildren();for(const entry of entries){if(!entry){$('menu-popup').append(document.createElement('hr'));continue;}if(inWordSession&&entry[0]==='插入 WPS')continue;const row=document.createElement('button');row.setAttribute('role','menuitem');const text=document.createElement('span');text.textContent=inWordSession&&entry[0]==='插入 Word'?'完成并返回 Word':entry[0];const key=document.createElement('small');key.textContent=entry[1];row.append(text,key);row.onclick=()=>{closePopups();entry[2]();};$('menu-popup').append(row);}$('menu-popup').hidden=false;placePopup($('menu-popup'),b);};$('menus').append(b);}
document.addEventListener('pointerdown',e=>{if(!e.target.closest('.popup,.menu-popup,.palette-button,#menus,.search-label'))closePopups();});
window.addEventListener('resize',()=>closePopups());
document.addEventListener('keydown',e=>{
 const dialog=document.querySelector('dialog[open]');if(dialog)return;
 if(e.target!==latex&&e.target!==$('template-search')&&FormulaStyles.shortcut(e))return;
 if(e.key==='Escape'){e.preventDefault();closePopups(true);return;}
 if(e.target===latex||e.target===$('template-search')){if(e.target===latex)return;if(e.key==='ArrowDown'&&!$('palette-popup').hidden){e.preventDefault();$('popup-grid').querySelector('button')?.focus();}return;}
 const focusTarget={F5:'#symbol-palettes button',F2:'#symbol-palettes button',F6:'#template-palettes button',F7:'#quick-bar button',F8:'#subject-tabs button',F9:'#history button'}[e.key];
 if(focusTarget){e.preventDefault();document.body.classList.remove('hide-toolbar');if(e.key==='F5'||e.key==='F2')document.body.classList.remove('hide-symbols');if(e.key==='F6')document.body.classList.remove('hide-templates');if(e.key==='F9')$('recent-panel').open=true;document.querySelector(focusTarget)?.focus();return;}
 if(e.key==='F1'){e.preventDefault();$('help-dialog').showModal();return;}
 if(e.ctrlKey&&!e.altKey){const k=e.key.toLowerCase();const action={f:()=>insertTemplate(TEMPLATE_PALETTES[1].items[0]),r:()=>insertTemplate(TEMPLATE_PALETTES[1].items[6]),'9':()=>insertTemplate(TEMPLATE_PALETTES[0].items[0]),o:click('open'),s:click('save'),n:click('clear')}[k];if(action){e.preventDefault();e.stopPropagation();action();return;}}
 const inGrid=e.target.closest('#popup-grid'),inBar=e.target.closest('.palette-buttons,#quick-bar,#subject-tabs,#subject-bar,#menus');
 if((inGrid||inBar)&&['ArrowRight','ArrowLeft','ArrowDown','ArrowUp','Home','End'].includes(e.key)){
  const parent=inGrid||inBar,buttons=[...parent.querySelectorAll('button')];let i=buttons.indexOf(e.target);if(i<0)return;
  const columns=inGrid?(getComputedStyle(parent).gridTemplateColumns.split(' ').length):buttons.length;
  i=e.key==='Home'?0:e.key==='End'?buttons.length-1:(i+({ArrowRight:1,ArrowLeft:-1,ArrowDown:columns,ArrowUp:-columns}[e.key])+buttons.length)%buttons.length;e.preventDefault();buttons[i].focus();
 }
},true);
for(let i=1;i<=40;i++){const s=document.createElement('span');s.textContent=i;$('ruler-ticks').append(s);}
customElements.whenDefined('math-field').then(async()=>{
 let draft='';try{draft=localStorage.getItem('formula-draft')||'';const zoom=localStorage.getItem('formula-zoom');if(['100','150','200','250'].includes(zoom)){$('zoom').value=zoom;mf.style.fontSize=(20*Number(zoom)/100)+'px';}}catch{}
 if(native){try{const info=await request('capabilities');const fontInfo=await request('style-fonts');await FormulaStyles.init(fontInfo.fonts);if(info.batchSession){await request("render-batch");return;}if(info.defaultFormat)FormulaStyles.useProfile(info.defaultFormat,true,false);inWordSession=Boolean(info.wordSession);if(inWordSession){const session=await request('word-session');draft=session.latex;FormulaStyles.restore(session.mathml);if(session.showSource)$("source-panel").open=true;$('word').textContent='完成并返回 Word';$('wps').hidden=true;$('capabilities').textContent='Word 插件编辑会话 · 完成后返回原位置';$('slot-hint').textContent='完成后点击“完成并返回 Word”。保存、导出仍可单独使用。';}else {FormulaStyles.restoreDraft();$('capabilities').textContent=`Word ${info.word?'✓':'未检测到'}　WPS ${info.wps?'✓':'未检测到'}　·　OpenMath 3.3.3`;} }catch(e){status(e.message,'error');}}
 else {await FormulaStyles.init();$('capabilities').textContent='OpenMath 3.3.3 · 浏览器预览';}
 setFormula(draft);status(inWordSession?'编辑完成后点击“完成并返回 Word”。':native?'准备就绪。选择模板或直接输入公式。':'浏览器预览：文件保存与文档插入请使用桌面版。');
});


async function formatFile(action){try{const result=await request(action,action==='format-save'?FormulaStyles.profile():{});if(result.cancelled)return;if(result.profile)FormulaStyles.useProfile(result.profile);status(action==='format-save'?'格式文件已保存。':'格式文件已应用。','success')}catch(error){status(error.message,'error')}}
