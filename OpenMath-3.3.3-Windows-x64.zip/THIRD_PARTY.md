OpenMath (formerly Formula Studio) uses MathLive 0.111.4 and bundled mathematical fonts, Microsoft WebView2 SDK 1.0.4314.35, and the separately installed WebView2 Runtime. License and notice texts for the redistributed components are in `licenses/`.

Versions 2.0 and 3.0 include a local modification to MathLive's MathML serializer for overline/underline atoms, so the body and bar decoration are preserved during export. The upstream source remains unchanged in vendor/. build.ps1 applies the documented, bounded patch when generating web/lib/mathlive.js. The MathLive MIT license remains included.

REA 6.8.0 was used as a development analysis tool and is installed separately under the workspace `.rea-tools` directory. Its license is included for reference; REA is not required to run the editor.

Microsoft Word and WPS are separate applications and are not included. The Office MML2OMML.XSL stylesheet is read from an existing local Office installation when present. It is not redistributed.

MathType is the reference application. Its application files, proprietary fonts, icons and private formats are not part of this package. Formula Studio is an independent implementation and is not affiliated with or endorsed by the MathType vendor.


Version 3.1 adds bounded MathLive patches to retain semantic style wrappers in MathML and attach role classes to editable glyphs. Original vendor sources remain unmodified. The locally installed Office transform is extended in memory for run font/bold/italic properties; the Office stylesheet and MathType fonts are not redistributed. Legacy Symbol/Euclid Extra/MT Extra font names are retained as preferences and rendered with Unicode-compatible Cambria Math.
Version 3.2 keeps MathLive's own glyph metrics inside radicals and normalizes mathematical radical runs to Cambria Math in Word. It removes invisible multiplication runs from radical layout. No fixed-length radical drawing or image replacement is used. The Office Ribbon grouping is an independent implementation based on a user-provided reference, with original icons drawn using System.Drawing and system fonts.

Version 3.2.1 marks explicit MathLive left/right fences in the MathML serializer and exempts scalable structure atoms from role-font overrides. These bounded local patches are applied by build.ps1; vendor sources remain unmodified. The local converter emits native growing Office Math delimiters and synchronizes structural control sizes with the formula. No additional fonts, Office stylesheets or MathType assets are redistributed.

Version 3.3 captures the actual MathLive editing surface through WebView2 CapturePreview, with locally implemented tiling, transparent-matte removal and DrawingML packaging. Word displays the embedded PNG and the Formula Studio add-in handles double-click editing through the official Word ApplicationEvents4 interface. The image carries Formula Studio source metadata. This is an independent object workflow, not a MathType MTEF/OLE implementation. No third-party screenshot libraries or MathType binaries were added.

Version 3.3.1 preserves MathLive's native fonts for extensible operators, font-private glyphs and composed negations. Integral operators consistently use the large mathematical glyph. Bounded local serializer patches output valid Unicode MathML for inequality, negation, standardized subset variants and logical long arrows. Original vendor files are unchanged; no new fonts or MathType assets are distributed.
